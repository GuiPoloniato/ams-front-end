export const lightTheme = {
  body: '#ffffff',
  text: '#121212',
}

export const darkTheme = {
  body: '#121212',
  text: '#ffffff',
}
