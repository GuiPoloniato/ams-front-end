import React from 'react';
import SideBar from '../../components/sideBar/sideBar';
import './style.css'

function Configuracao() {
    return(
        <div className="body-Configuracao">
            <SideBar />
        </div>
    )
}
export default Configuracao;